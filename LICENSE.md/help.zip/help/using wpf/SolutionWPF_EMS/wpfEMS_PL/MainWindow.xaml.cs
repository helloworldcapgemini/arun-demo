﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using wpfEMS_BAL;
using wpfEMS_Entity;

namespace wpfEMS_PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Employee _employee = null;
        Gender _gender = Gender.Male;
        Department _department = Department.Admin;
        List<string> _knownLangage = null;

        public bool AddMode { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            AddMode = true;
        }

        void Reset()
        {
            _employee = null;
            _gender = Gender.Male;
            _department = Department.Admin;
            _knownLangage = null;
            txtUserName.Text = "";
            txtPhone.Text = "";
            dpDOJ.Text = "";
            rdoMale.IsChecked = false;
            rdoFemale.IsChecked = false;
            rdoOther.IsChecked = false;

            chkEn.IsChecked = false;
            chkHi.IsChecked = false;
            chkMh.IsChecked = false;
            chkTe.IsChecked = false;


        }
        private void ButtonAdd_Click(object sender, RoutedEventArgs e)
        {
            _employee = new Employee();
            _employee.FullName = txtUserName.Text;
            _employee.Gender = _gender;
            _employee.Department = _department;
            _employee.DOJ = DateTime.Parse(dpDOJ.Text);
            _employee.LanguageKnown = _knownLangage;
            _employee.MobileNo = txtPhone.Text;

            if (AddMode)
                BAL.Add(_employee);
            else
                BAL.Update(_employee);

            Reset();
            Close();
        }

        private void radioGender_Checked(object sender, RoutedEventArgs e)
        {
            var radioButton = sender as RadioButton;
            if( radioButton != null)
            {
                string txt = radioButton.Content.ToString();
                switch(txt)
                {
                    case "Male": _gender = Gender.Male; break;
                    case "Female": _gender = Gender.Female; break;
                    case "Other": _gender = Gender.Other; break;
                }
            }
        }

        private void languageKnown_Checked(object sender, RoutedEventArgs e)
        {
            var checkBox = sender as CheckBox;
            if (_knownLangage == null) _knownLangage = new List<string>();

            if( checkBox != null)
            {
                string txt = checkBox.Content.ToString();
                _knownLangage.Add(txt);
            }
        }

        private void DepartmentList_Selected(object sender, RoutedEventArgs e)
        {
            var department = sender as ListBoxItem;
            if( department != null)
            {
                string txt = department.Content.ToString();
                _department = (Department)Enum.Parse(typeof(Department), txt);
            }
        }

        private void ButtonReset_Click(object sender, RoutedEventArgs e)
        {
            Reset();
        }

       
    }
}
