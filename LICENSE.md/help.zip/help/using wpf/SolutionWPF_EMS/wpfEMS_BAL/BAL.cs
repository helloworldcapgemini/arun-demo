﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wpfEMS_DAL;
using wpfEMS_Entity;

namespace wpfEMS_BAL
{
    public class BAL
    {
        public static void Add(Employee employee)
        {
            DAL.Add(employee);
        }

        public static void Update(Employee employee)
        {
            DAL.UpdateByName(employee);
        }

        public static void Delete(int id)
        {
            DAL.DeleteById(id);

        }

        public static List<Employee> GetAll()
        {
            return DAL.SelectAll();
        }

    }
}
