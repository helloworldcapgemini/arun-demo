﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using wpfEMS_Entity;

namespace wpfEMS_DAL
{
    public class DAL
    {
        static List<Employee> employees = new List<Employee>();

        public static bool Add(Employee employee)
        {
            bool IsSuccess = false;
            try
            {
                employees.Add(employee);
                IsSuccess = true;
            }
            catch (Exception)
            {
                IsSuccess = false;
                throw;
            }

            return IsSuccess;
        }

        public static Employee SearchByID(int empId)
        {
            Employee employee = null;
            foreach (Employee e in employees)
            {
                if(e.Id == empId)
                {
                    employee = e;
                    break;
                }
            }

            return employee;
        }

        public static bool UpdateByName(Employee employee)
        {
            Employee emp = null;
            bool IsSuccess = false;
            try
            {
                foreach(Employee e in employees)
                {
                    if(e.FullName == employee.FullName)
                    {
                        emp = e;
                        break;
                    }
                }

                if( emp != null)
                {
                    emp.Department = employee.Department;
                    emp.DOJ = employee.DOJ;
                    emp.LanguageKnown = employee.LanguageKnown;
                    emp.MobileNo = employee.MobileNo;
                    emp.Gender = employee.Gender;
                    IsSuccess = true;
                }
            }
            catch (Exception)
            {
                IsSuccess = false;
                throw;
            }

            return IsSuccess;
        }

        public static bool UpdateById(Employee employee)
        {
            Employee emp = null;
            bool IsSuccess = false;
            try
            {
                foreach (Employee e in employees)
                {
                    if (e.Id == employee.Id)
                    {
                        emp = e;
                        break;
                    }
                }

                if (emp != null)
                {
                    emp.Department = employee.Department;
                    emp.DOJ = employee.DOJ;
                    emp.LanguageKnown = employee.LanguageKnown;
                    emp.MobileNo = employee.MobileNo;
                    emp.Gender = employee.Gender;
                    IsSuccess = true;
                }
            }
            catch (Exception)
            {
                IsSuccess = false;
                throw;
            }

            return IsSuccess;
        }

        public static bool DeleteById(int id)
        {
            Employee emp = null;
             bool IsSuccess = false;
             try
             {
                 foreach (Employee e in employees)
                 {
                     if (e.Id == id)
                     {
                         emp = e;
                         break;
                     }
                 }

                 if (emp != null)
                 {
                     employees.Remove(emp);
                     IsSuccess = true;
                 }
             }
             catch (Exception)
             {
                 IsSuccess = false;
                 throw;
             }
            return IsSuccess;
        }

        public static List<Employee> SelectAll()
        {
            return employees;
        }


        public static bool SerializedData()
        {
            bool IsSuccess = false;
            try
            {
                Stream stream = File.Open("employee.dat", FileMode.Create, FileAccess.ReadWrite);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(stream, employees );
                stream.Close();
                IsSuccess = true;
            }
            catch (Exception)
            {
                IsSuccess = false;
                throw;
            }

            return IsSuccess;
        }


        public static bool DeSerializedData()
        {
            bool IsSuccess = false;
            try
            {
                Stream stream = File.Open("employee.dat", FileMode.Open, FileAccess.Read);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                List<Employee> newEmployees = (List<Employee>)binaryFormatter.Deserialize(stream);
                stream.Close();

                // Merge DeSearalized Data to In  memory Data
                foreach(Employee emp in  newEmployees)
                {
                    employees.Add(emp);
                }
                IsSuccess = true;
            }
            catch (Exception)
            {
                IsSuccess = false;
                throw;
            }

            return IsSuccess;
        }
    }

    
}
