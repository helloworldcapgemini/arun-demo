﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wpfEMS_Entity
{

    public enum Department
    {
        HR, Admin, Operation, Finance
    }

    public enum Gender
    {
        Male, Female, Other
    }
    public class Employee
    {
        static int count = 0;
        int empId;

        public int Id
        {
              get{return empId;}
             set { empId=value;}
        }

        public string FullName { get; set; }
        public DateTime DOJ { get; set; }
        public Gender Gender { get; set; }
        public Department Department { get; set; }
        public string MobileNo { get; set; }
        public List<string> LanguageKnown { get; set; }

        public Employee()
        {
            count++;
            Id = count;
        }

        public Employee(string FullName, Gender gender, DateTime DOJ, Department Department,
            string MobileNo, List<string> LanguageKnown)
        {
            count++;
            Id = count;
            
            this.FullName = FullName;
            this.Gender = Gender;
            this.DOJ = DOJ;
            this.Department = Department;
            this.MobileNo = MobileNo;
            this.LanguageKnown = LanguageKnown;
        }
        
    }

}
