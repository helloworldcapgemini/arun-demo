﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wpfEMS_Entity
{

    public enum Department
    {
        HR, Admin, Operation, Finance
    }

    public enum Gender
    {
        Male, Female, Other
    }


    public class Employee : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private void OnPropertyChanged(string property)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(property));
        }

        //static int count = 0;
        int empId;

        public int Id
        {
          get { return empId; }
            set { empId = value; OnPropertyChanged("Id"); }
        }

        string fullName;
        public string FullName { 
            get { return fullName; }
            set { fullName = value; OnPropertyChanged("FullName");}
        }
        DateTime doj;
        public DateTime DOJ {
            get { return doj; }
            set { doj = value; OnPropertyChanged("DOJ"); }
        }
        Gender gender;
        public Gender Gender {
            get { return gender; }
            set { gender = value; OnPropertyChanged("Gender"); }
        }
        Department dept;
        public Department Department {
            get { return dept; }
            set { dept = value; OnPropertyChanged("Department"); }
        }

        string mob;
        public string MobileNo
        {
            get { return mob; }
            set { mob = value; OnPropertyChanged("MobileNo"); }
        }
        List<string> lang;
        public List<string> LanguageKnown {
            get { return lang; }
            set { lang = value; OnPropertyChanged("LanguageKnown"); }
        }
       

        public Employee()
        {
            //count++;
            //Id = count;
        }

        public Employee(int id, string FullName, Gender gender, DateTime DOJ, Department Department,
            string MobileNo, List<string> LanguageKnown)
        {
            //count++;
            Id = id;// count;
            this.FullName = FullName;
            this.Gender = Gender;
            this.DOJ = DOJ;
            this.Department = Department;
            this.MobileNo = MobileNo;
            this.LanguageKnown = LanguageKnown;
        }
        
    }

}
