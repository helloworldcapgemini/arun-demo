﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wpfEMS_Entity;
using wpfEMS_DAL;
namespace wpfEMS_BAL
{
    
    public class SQL_BAL
    {
        string connection = "";
        sql_DAL dal = null;

        public SQL_BAL(string connection)
        {
            this.connection = connection;
            this.dal = new sql_DAL(this.connection);
        }

        public bool Add(Employee employee)
        {
            bool IsSuccess = false;
            try
            {
                dal.Create(employee);
                
                IsSuccess = true;
            }
            catch (Exception)
            {
                IsSuccess = false;
                throw;
            }

            return IsSuccess;

        }

        public bool Update(Employee employee)
        {
            bool IsSuccess = false;
            try
            {
                dal.Update(employee);
                IsSuccess = true;
            }
            catch (Exception)
            {
                IsSuccess = false;
                throw;
            }

            return IsSuccess;

        }

        public bool Delete(int id)
        {
            bool IsSuccess = false;
            try
            {
                dal.Delete(id);
                IsSuccess = true;
            }
            catch (Exception)
            {
                IsSuccess = false;
                throw;
            }

            return IsSuccess;
        }

        public List<Employee> GetAll()
        {
            return this.dal.Select();
        }

        public Employee Search(int id)
        {
            return this.dal.Search(id);
        }

    }
}
