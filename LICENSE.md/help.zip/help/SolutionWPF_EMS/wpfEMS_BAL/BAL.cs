﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wpfEMS_DAL;
using wpfEMS_Entity;

namespace wpfEMS_BAL
{
    public class BAL
    {
        public static bool Add(Employee employee)
        {
            bool IsSuccess = false;
            try
            {
                DAL.Add(employee);
                IsSuccess = true;
            }
            catch (Exception)
            {
                IsSuccess = false;
                throw;
            }

            return IsSuccess;
            
        }

        public static bool Update(Employee employee)
        {
            bool IsSuccess = false;
            try
            {
                DAL.UpdateById(employee);
                IsSuccess = true;
            }
            catch (Exception)
            {
                IsSuccess = false;
                throw;
            }

            return IsSuccess;
            
        }

        public static bool Delete(int id)
        {
            bool IsSuccess = false;
            try
            {
                DAL.DeleteById(id);
                IsSuccess = true;
            }
            catch (Exception)
            {
                IsSuccess = false;
                throw;
            }

            return IsSuccess;
        }

        public static List<Employee> GetAll()
        {
            return DAL.SelectAll();
        }

    }
}
