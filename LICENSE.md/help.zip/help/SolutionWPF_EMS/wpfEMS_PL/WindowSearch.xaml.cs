﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using wpfEMS_BAL;

namespace wpfEMS_PL
{
    /// <summary>
    /// Interaction logic for WindowSearch.xaml
    /// </summary>
    public partial class WindowSearch : Window
    {

        public bool DeleteMode { get; set; }
        public WindowSearch()
        {
            InitializeComponent();
            DeleteMode = true;
        }

        private void ButtonSubmit_Click(object sender, RoutedEventArgs e)
        {
            if( DeleteMode == true)
            BAL.Delete(int.Parse(txtID.Text));
            
        }

        private void ButtonReset_Click(object sender, RoutedEventArgs e)
        {
            txtID.Text = "";
        }
    }
}
