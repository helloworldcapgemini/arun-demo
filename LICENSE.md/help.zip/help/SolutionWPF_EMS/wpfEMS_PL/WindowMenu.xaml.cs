﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using wpfEMS_BAL;
using wpfEMS_Entity;

namespace wpfEMS_PL
{
    /// <summary>
    /// Interaction logic for WindowMenu.xaml
    /// </summary>
    public partial class WindowMenu : Window
    {
        public WindowMenu()
        {
            InitializeComponent();
        }

        private void ButtonViewAll_Click(object sender, RoutedEventArgs e)
        {
            WindowShowAll showAllWindow = new WindowShowAll();
            showAllWindow.AddHeaderValues("ID", "FULL NAME", "GENDER", "DATE OF JOINING", "DEPARTMENT", "KNOWN LANGUAGE", "PHONE NO.");

            foreach (Employee emp in BAL.GetAll())
            {
                StringBuilder lang = new StringBuilder();
                foreach (String ln in emp.LanguageKnown)
                {
                    lang.Append(ln).Append(" ");
                }

                showAllWindow.AddValues(
                    emp.Id.ToString(),
                    emp.FullName,
                    emp.Gender.ToString(),
                    emp.DOJ.ToString(),
                    emp.Department.ToString(),
                    lang.ToString(),
                    emp.MobileNo
                    );
            }
            showAllWindow.Show();
        }

        private void ButtonAdd_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.AddMode = true;
            mainWindow.ShowDialog();
        }

        private void ButtonUpdate_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.AddMode = false;
            mainWindow.ShowDialog();
        }

        private void ButtonDelete_Click(object sender, RoutedEventArgs e)
        {
            WindowSearch windowSearch = new WindowSearch();
            windowSearch.DeleteMode = true;
            windowSearch.ShowDialog();
        }
    }
}
