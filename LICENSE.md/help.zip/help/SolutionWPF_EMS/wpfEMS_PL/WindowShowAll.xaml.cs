﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace wpfEMS_PL
{
    /// <summary>
    /// Interaction logic for WindowShowAll.xaml
    /// </summary>
    public partial class WindowShowAll : Window
    {
        int rowCount = 0;
        public WindowShowAll()
        {
            InitializeComponent();
        }

        public void AddValues(string id, string name, string gender, string doj, string dept, string languages, string phone)
        {
            RowDefinition rowDefinition = new RowDefinition();
            rowDefinition.Height = new GridLength(30);
            mainGrid.RowDefinitions.Add( rowDefinition );

            TextBlock tbId = new TextBlock();
            tbId.Text = id;
            
            Grid.SetColumn(tbId, 0);
            Grid.SetRow(tbId, rowCount);
            mainGrid.Children.Add(tbId);

            TextBlock tbName = new TextBlock();
            tbName.Text = name;
            Grid.SetColumn(tbName, 1);
            Grid.SetRow(tbName, rowCount);
            mainGrid.Children.Add(tbName);

            TextBlock tbGender = new TextBlock();
            tbGender.Text = gender;
            Grid.SetColumn(tbGender, 2);
            Grid.SetRow(tbGender, rowCount);
            mainGrid.Children.Add(tbGender);

            TextBlock tbDoj = new TextBlock();
            tbDoj.Text = doj;
            Grid.SetColumn(tbDoj, 3);
            Grid.SetRow(tbDoj, rowCount);
            mainGrid.Children.Add(tbDoj);

            TextBlock tbDept = new TextBlock();
            tbDept.Text = dept;
            Grid.SetColumn(tbDept, 4);
            Grid.SetRow(tbDept, rowCount);
            mainGrid.Children.Add(tbDept);

            TextBlock tbLang = new TextBlock();
            tbLang.Text = languages;
            Grid.SetColumn(tbLang, 5);
            Grid.SetRow(tbLang, rowCount);
            mainGrid.Children.Add(tbLang);

            TextBlock tbPhone = new TextBlock();
            tbPhone.Text = phone;
            Grid.SetColumn(tbPhone, 6);
            Grid.SetRow(tbPhone, rowCount);
            mainGrid.Children.Add(tbPhone);
            rowCount++;

        }

        public void AddHeaderValues(string id, string name, string gender, string doj, string dept, string languages, string phone)
        {
            RowDefinition rowDefinition = new RowDefinition();
            rowDefinition.Height = new GridLength(30);
            mainGrid.RowDefinitions.Add(rowDefinition);

            TextBlock tbId = new TextBlock();
            tbId.Text = id;
            tbId.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
            tbId.FontWeight = System.Windows.FontWeights.ExtraBold;
            Grid.SetColumn(tbId, 0);
            Grid.SetRow(tbId, rowCount);
            mainGrid.Children.Add(tbId);

            TextBlock tbName = new TextBlock();
            tbName.Text = name;
            tbName.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
            tbName.FontWeight = System.Windows.FontWeights.ExtraBold;
            Grid.SetColumn(tbName, 1);
            Grid.SetRow(tbName, rowCount);
            mainGrid.Children.Add(tbName);

            TextBlock tbGender = new TextBlock();
            tbGender.Text = gender;
            tbGender.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
            tbGender.FontWeight = System.Windows.FontWeights.ExtraBold;
            Grid.SetColumn(tbGender, 2);
            Grid.SetRow(tbGender, rowCount);
            mainGrid.Children.Add(tbGender);

            TextBlock tbDoj = new TextBlock();
            tbDoj.Text = doj;
            tbDoj.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
            tbDoj.FontWeight = System.Windows.FontWeights.ExtraBold;
            Grid.SetColumn(tbDoj, 3);
            Grid.SetRow(tbDoj, rowCount);
            mainGrid.Children.Add(tbDoj);

            TextBlock tbDept = new TextBlock();
            tbDept.Text = dept;
            tbDept.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
            tbDept.FontWeight = System.Windows.FontWeights.ExtraBold;
            Grid.SetColumn(tbDept, 4);
            Grid.SetRow(tbDept, rowCount);
            mainGrid.Children.Add(tbDept);

            TextBlock tbLang = new TextBlock();
            tbLang.Text = languages;
            tbLang.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
            tbLang.FontWeight = System.Windows.FontWeights.ExtraBold;
            Grid.SetColumn(tbLang, 5);
            Grid.SetRow(tbLang, rowCount);
            mainGrid.Children.Add(tbLang);

            TextBlock tbPhone = new TextBlock();
            tbPhone.Text = phone;
            tbPhone.HorizontalAlignment = System.Windows.HorizontalAlignment.Center;
            tbPhone.FontWeight = System.Windows.FontWeights.ExtraBold;
            Grid.SetColumn(tbPhone, 6);
            Grid.SetRow(tbPhone, rowCount);
            mainGrid.Children.Add(tbPhone);
            rowCount++;

        }
    }
}
