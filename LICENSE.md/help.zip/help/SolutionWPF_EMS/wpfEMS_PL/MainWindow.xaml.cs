﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using wpfEMS_BAL;
using wpfEMS_Entity;

namespace wpfEMS_PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Employee _employee = null;
        Gender _gender = Gender.Male;
        Department _department = Department.Admin;
        List<string> _knownLangage = null;

        SQL_BAL sqlBAL = null;
        int employeeId = -1;
        public bool AddMode { get; set; }

        public MainWindow()
        {
            InitializeComponent();
            AddMode = true;

            string connString = ConfigurationManager.ConnectionStrings["conn1"].ConnectionString;
            sqlBAL = new SQL_BAL(connString);

            GetAll();
            
        }

        void Reset()
        {
            _employee = null;
            _gender = Gender.Male;
            _department = Department.Admin;
            _knownLangage = null;
            txtUserName.Text = "";
            txtPhone.Text = "";
            dpDOJ.Text = "";
            rdoMale.IsChecked = false;
            rdoFemale.IsChecked = false;
            rdoOther.IsChecked = false;

            chkEn.IsChecked = false;
            chkHi.IsChecked = false;
            chkMh.IsChecked = false;
            chkTe.IsChecked = false;


        }
        private void ButtonAdd_Click(object sender, RoutedEventArgs e)
        {
            
            _employee = new Employee();
            _employee.FullName = txtUserName.Text;
            _employee.Gender = _gender;
            _employee.Department = _department;
            _employee.DOJ = DateTime.Parse(dpDOJ.Text);
            _employee.LanguageKnown = _knownLangage;
            _employee.MobileNo = txtPhone.Text;

            
            sqlBAL.Add(_employee);
            

            Reset();
            GetAll();
            
        }

        private void radioGender_Checked(object sender, RoutedEventArgs e)
        {
            var radioButton = sender as RadioButton;
            if( radioButton != null)
            {
                string txt = radioButton.Content.ToString();
                switch(txt)
                {
                    case "Male": _gender = Gender.Male; break;
                    case "Female": _gender = Gender.Female; break;
                    case "Other": _gender = Gender.Other; break;
                }
            }
        }

        private void languageKnown_Checked(object sender, RoutedEventArgs e)
        {
            var checkBox = sender as CheckBox;
            if (_knownLangage == null) _knownLangage = new List<string>();

            if( checkBox != null)
            {
                string txt = checkBox.Content.ToString();
                _knownLangage.Add(txt);
            }
        }

        private void DepartmentList_Selected(object sender, RoutedEventArgs e)
        {
            var department = sender as ListBoxItem;
            if( department != null)
            {
                string txt = department.Content.ToString();
                _department = (Department)Enum.Parse(typeof(Department), txt);
            }
        }

        bool dataGridStateVisible = true;
        private void ButtonShowAllData_Click(object sender, RoutedEventArgs e)
        {
            if( dataGridStateVisible == true)
            {
                btnShowAll.Content = "Hide All Employee";
                dataStack.Visibility = System.Windows.Visibility.Visible;
                dataGridStateVisible = false;
                GetAll();
            }
            else
            {
                btnShowAll.Content = "Show All Employee";
                dataStack.Visibility = System.Windows.Visibility.Hidden;
                dataGridStateVisible = true;
            
            }
           
        }

        void GetAll()
        {
            //Reset();
            List<Employee> emps = sqlBAL.GetAll();

            if (emps == null) return;
            gridView.ItemsSource = emps;

            //DataTemplateSelector dts = new DataTemplateSelector();
           
            //DataTemplate dt1 = new DataTemplate()
            //gridView.ItemTemplateSelector = dts 

            cbxtUserId.Items.Clear();
            foreach (Employee emp in emps)
            {
                cbxtUserId.Items.Add(emp.Id);
            }
            cbxtUserId.SelectedIndex = 0;

            
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            employeeId = int.Parse(cbxtUserId.SelectedValue.ToString());

            _employee = new Employee();
            _employee.Id = employeeId;
            _employee.FullName = txtUserName.Text;
            _employee.Gender = _gender;
            _employee.Department = _department;
            _employee.DOJ = DateTime.Parse(dpDOJ.Text);
            _employee.LanguageKnown = _knownLangage;
            _employee.MobileNo = txtPhone.Text;


            sqlBAL.Update(_employee);


            Reset();
            GetAll();
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            employeeId = int.Parse(cbxtUserId.SelectedValue.ToString());
            sqlBAL.Delete(employeeId);
            GetAll();
        }

        private void cbxtUserId_Changed(object sender, SelectionChangedEventArgs e)
        {
            
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            employeeId = int.Parse(cbxtUserId.SelectedValue.ToString());
            Employee emp = sqlBAL.Search(employeeId);

            

            txtUserName.Text = emp.FullName;
            
            switch (emp.Gender)
            {
                case Gender.Male: rdoMale.IsChecked = true; break;
                case Gender.Female: rdoFemale.IsChecked = true; break;
                case Gender.Other: rdoOther.IsChecked = true; break;
            }
            
            dpDOJ.Text = emp.DOJ.ToString();

            switch(emp.Department)
            {
                case Department.Admin: cbxDept.SelectedIndex = 1; break;
                case Department.HR: cbxDept.SelectedIndex = 0; break;
                case Department.Operation: cbxDept.SelectedIndex = 2; break;
                case Department.Finance: cbxDept.SelectedIndex = 3; break;
            }

            foreach(string lang in emp.LanguageKnown)
            {
                if (lang == "English")chkEn.IsChecked = true;
                if (lang == "Hindi") chkHi.IsChecked = true;
                if (lang == "Marathi") chkMh.IsChecked = true;
                if (lang == "Telgue") chkTe.IsChecked = true;

            }

            txtPhone.Text = emp.MobileNo;
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            Reset();
        }
       
    }
}
