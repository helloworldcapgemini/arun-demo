﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wpfEMS_Entity;

namespace wpfEMS_DAL
{
    public class sql_DAL
    {
        SqlConnection connection = null;
        SqlCommand command = null;
        SqlDataReader reader = null;



        string connectionString = "";
        public sql_DAL(string conString)
        {
            connectionString = conString;
            connection = new SqlConnection(connectionString);
        }


        public int Create(Employee emp )
        {
            string cmd;// = @"INSERT INTO dbo.Table_EMP_138203A VALUES('Arun', '20171031 02:55:09 AM', 'Male', 'Admin', '9999999999', 'English, Hindi')";
            string lang = "";
            foreach (string s in emp.LanguageKnown) lang += s + ",";
            cmd = @"INSERT INTO dbo.Table_EMP_138203A VALUES('"+emp.FullName+"', '"+emp.DOJ+"', '"+
                emp.Gender.ToString()+"', '"+emp.Department.ToString()+"', '"+emp.MobileNo+"', '"+lang+"')";
            
            command = new SqlCommand(cmd, connection);
            connection.Open();
            int ret = command.ExecuteNonQuery();
            connection.Close();
            return ret;
        }

        public int Delete(int id)
        {
            string cmd;
            cmd = @"DELETE FROM dbo.Table_EMP_138203A where Id = '"+id+"' ";
            command = new SqlCommand(cmd, connection);
            connection.Open();
            int ret = command.ExecuteNonQuery();
            connection.Close();
            return ret;
        }

        public int Update(Employee emp)
        {
            string cmd;
            string lang = "";
            foreach (string s in emp.LanguageKnown) lang += s + ",";
            cmd = @"UPDATE dbo.Table_EMP_138203A Set FirstName='" + emp.FullName + "',DOJ= '" + emp.DOJ + "',Gender= '" +
                emp.Gender.ToString() + "',Department= '" + emp.Department.ToString() + "',MobileNo = '" + emp.MobileNo + "', LanguageKnown = '" + lang + "' Where Id = '" + emp.Id + "'; ";
            command = new SqlCommand(cmd, connection);
            connection.Open();
            int ret = command.ExecuteNonQuery();
            connection.Close();
            return ret;
        }

        public Employee Search(int id)
        {
            string cmd;// = @"INSERT INTO dbo.Table_EMP_138203A VALUES('Arun', '20171031 02:55:09 AM', 'Male', 'Admin', '9999999999', 'English, Hindi')";
            cmd = @"SELECT * FROM dbo.Table_EMP_138203A Where Id = '"+id+"'";

            command = new SqlCommand(cmd, connection);
            connection.Open();
            reader = command.ExecuteReader();

            List<Employee> emps = new List<Employee>();

            while (reader.Read())
            {
                Employee emp = new Employee();
                emp.Id = (int)reader["Id"];
                emp.FullName = (string)reader["FirstName"];
                emp.Gender = (Gender)Enum.Parse(typeof(Gender), (string)reader["Gender"]);
                //string date = (string)reader["DOJ"];
                emp.DOJ = (DateTime)reader["DOJ"]; // DateTime.Now; //DateTime.ParseExact( (string)reader["DOJ"], "MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture );
                emp.MobileNo = (string)reader["MobileNo"];
                string[] langs = ((string)reader["LanguageKnown"]).Split(',');
                
                emp.LanguageKnown = langs.ToList();
                emps.Add(emp);
            }

            connection.Close();

            return emps[0];

        }
        public List<Employee> Select()
        {
            string cmd;// = @"INSERT INTO dbo.Table_EMP_138203A VALUES('Arun', '20171031 02:55:09 AM', 'Male', 'Admin', '9999999999', 'English, Hindi')";
            cmd = @"SELECT * FROM dbo.Table_EMP_138203A";

            command = new SqlCommand(cmd, connection);
            connection.Open();
            reader = command.ExecuteReader();

            List<Employee> emps = new List<Employee>();

            while( reader.Read() )
            {
                Employee emp = new Employee();
                emp.Id = (int)reader["Id"];
                emp.FullName = (string) reader["FirstName"];
                emp.Gender = (Gender)Enum.Parse(typeof(Gender), (string)reader["Gender"]);
                //string date = (string)reader["DOJ"];
                emp.DOJ = (DateTime)reader["DOJ"]; // DateTime.Now; //DateTime.ParseExact( (string)reader["DOJ"], "MM/dd/yyyy", System.Globalization.CultureInfo.InvariantCulture );
                emp.MobileNo = (string)reader["MobileNo"];
                string[] langs = ((string)reader["LanguageKnown"]).Split(',');

                emp.LanguageKnown = langs.ToList() ;
                emps.Add(emp);
            }

            connection.Close();

            return emps;
            
        }

    }
}
